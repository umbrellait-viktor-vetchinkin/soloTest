const fs = require('fs');
const FormData = require('form-data');
const {
    randomUUID,
} = require('node:crypto');

function screenshots (requestParams, context, ee, next) {
    const fileId = randomUUID();
    const newFileName = `${fileId}--screen1.png`;
    const form = new FormData();
    form.append('files', fs.createReadStream(__dirname + '/screen1.png'), newFileName);
    requestParams.body = form;
    return next();
}

module.exports = {
    addMultipartFormData,
}