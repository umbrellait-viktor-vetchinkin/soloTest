const formData = require('form-data');

function setupMultipartFormData(requestParams, context, ee, next) {
    const form = new formData();
    form.append('file', fs.createReadStream('/1-38.json'));
    requestParams.body = form;
    return next();
}

module.exports = {
    setupMultipartFormData,
}
