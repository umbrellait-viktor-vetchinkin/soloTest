const fs = require('fs');

module.exports = {
    setJSONBody,
    logResponse,
}

function setJSONBody(requestParams, context, ee, next) {
    const fileId = `ddeb27fb-d9a0-4624-be4d-4615062daed4`;
    const newFileName = `${fileId}--1-38.json`;
    const formData = {
        files: {value: fs.createReadStream(__dirname + '/1-38.json'), options:{filename: newFileName, contentType:"application/json"}}
    };

    requestParams.formData = Object.assign({}, requestParams.formData, formData);

    return next();
}

function logResponse(requestParams, response, context, ee, next) {
    console.log('[DEBUG] Response: ', response.body);
    return next();
}