
function jsonArray (requestParams, response, context, events, next) {
    const result = JSON.parse(response.body).data.app.workspaceOverview.translation.targetLanguages.map(l => l.id)
    console.log(context)
    context.vars = {...context.vars,targetLanguageIds: result }
    return next();
}

module.exports = {
    jsonArray,
}