const fs = require('fs');
const FormData = require('form-data');
const {
    randomUUID,
} = require('node:crypto');
const POPULAR_LANGUAGES = [

    'de', // 'German',
  //  'Italian',
   'ja',// 'Japanese',
 //   'Korean',
 //   'Dutch',
 'ru', //   'Russian',
   'es', //'Spanish',
  //  'Polish',
  //  'Turkish',
  'zh_Hant', //  'Traditional Chinese',
   // 'Swedish',
    //'Thai',
   // 'Vietnamese',
   // 'Danish',
   // 'Finnish',
   // 'Czech',
];


function addMultipartFormData(requestParams, context, ee, next) {
    const fileId = randomUUID();
    const randomId = Math.floor(Math.random()* 3)
    const newFileName = fileId + '--' + randomId + '.json';

    const form = new FormData();
    form.append('files', fs.createReadStream(__dirname + '/json/' + randomId +  '.json'), newFileName);
    requestParams.body = form;
    return next();
}
function addMultipartFormDataCSV(requestParams, context, ee, next) {
    const fileId = randomUUID();
    const randomId = Math.floor(Math.random()* 2)
    const newFileName = fileId + '--' + randomId + '.csv';

    const form = new FormData();
    form.append('files', fs.createReadStream(__dirname + '/csv/' + randomId +  '.csv'), newFileName);
    requestParams.body = form;
    return next();
}

function jsonArray (requestParams, response, context, events, next) {
    const result = JSON.parse(response.body).data.app.workspaceOverview.translation.targetLanguages.map(l => l.id)
    context.vars = {...context.vars,targetLanguageIds: result }
    return next();
}

function jsonArrayLang (requestParams, response, context, events, next) {

  //  const language_ids = JSON.parse(response.body).data.locale.standard.languages.map(z => z.id)
    const result = new Set();
    const lang_num = Math.floor(Math.random() * 3) +2;
    for (let i = 0; i < lang_num; i++) {
        const index = Math.floor(Math.random() * POPULAR_LANGUAGES.length);
        const lang = POPULAR_LANGUAGES[index];
        result.add(lang);
    }
    context.vars = {...context.vars,localeLangIds: [...result] }
    return next();
}
function jsonArrayTags (requestParams, response, context, events, next) {
    const result = JSON.parse(response.body).data.app.platforms.map(d => d.tags).reduce(el => el);
    context.vars = {...context.vars,tags: result }
    return next();
}
function screenshots (requestParams, context, ee, next) {
    const fileId = randomUUID();
    const newFileName = `${fileId}--screen1.png`;
    const form = new FormData();
    form.append('files', fs.createReadStream(__dirname + '/screen1.png'), newFileName);
    form.append("translationUnitId", context.vars.translationUnitId)
    requestParams.body = form;
    return next();
}
//module.exports = {
//    statusCREATED: statusCREATED,
//};
function statusCREATED(context, next) {
    const continueLooping = context.vars.status !== "CREATED";
    // While `continueLooping` is true, the `next` function will
    // continue the loop in the test scenario.
    return next(continueLooping);
}
function statusIMPORTED(context, next) {
    const continueLooping = context.vars.status !== "IMPORTED";
    // While `continueLooping` is true, the `next` function will
    // continue the loop in the test scenario.
    return next(continueLooping);
}



module.exports = {
    addMultipartFormData, jsonArray, jsonArrayTags, jsonArrayLang, screenshots, statusIMPORTED, statusCREATED, addMultipartFormDataCSV
}
//translationUnitId