---
    config:
target: https://dashboard.oneskyhq-stag.com
    phases:
        - duration: 1
arrivalRate: 1
scenarios:
    - name: languages
flow:
    - post:
url: /api/graphql
headers:
    Cookie: __Host-GCP_IAP_AUTH_TOKEN_24134F357731336F=ASIj7MiMmMisplKfJ3cdYk7eiHlKCgdHuqYlTrsUBiVKHf-XUOn2OmkgamTbxkaIgaZf_epK7X3EZTYh9i1NetXotbNP31hW6uHb_aBS1bgSe1iyPbSoJcvlun3aaNxtxmj901Nv32FSm6A_8aqatnyTZdqEMBY7H6psZF25Ktn4K_jTJhxRjqnvC1e-Xn9ETPO_Sl9bcE3I9m_t5mJ0R7nt_kjnhUirm1FIBnpKNKWPNw21S4rbC_ZcraGqRog_J0dvOO8ckto262sBePjYO_d3JUSN3i6-TAKoAooDiblSVAGmjdeVIZ2_gPOyYAh6jZZkdK014JQo7RburRkzG6YIFSlEKqXbOSyuPsYjQIvXDZcaQJPGT4HsKDmqgQcfNaqY8gUJGUI8mSGzlVlw8dV8kdTBJwl9Q-C3krq-k5NEqXYF0G5ndrKdyFRkjvTp31wuZDRbZYot4SBaKppQepiV9H2JheVKpf_6a6kJOFJxBinIUWTF2vigN61RBKxCgDOCI9FGHMtttfZwWXIbHU9mIb3bildZCObgwmmDIOVc1t51SLo6CVB8PoxDTt0Vc4_1H8WWb7UkC4Acr6x1C4Q8BvKHElnJieC1_ziNFqV-avzNCOe54cDwVt1SCD9G7w_S06friUenIaPVrVz3qWicNH8fFiWM4_tgcCy0gClot9-s78CAb6yKslM7YSC4kJIiPriIgOqIiqstdlYI8UZ72fmajQCaZuyuE797AQmtkAc3GeQ5-NLLSmo7tU6MKiF-fUFTADthJtGqae1OrVeG43cAE2UyWowvEmrrragTAC7csoEkPnvFZ-aGwXD2Nm55Ehxr4KFWXz-MgUzdkcEucknjPm7prG9U1hmyuOVSCIJM3Bf_xIOvZ2xUASiEEUsPE5wEuQUXvy2UNuHu2ERh7lOfskcLBhovZY9FpIS7O1iqI07Gxer2ERT5sKHhysltrOiA4iamHYVmBacEaCKKI4OJCzsEIM4TJCzqII_ysk11hOb2GFOUnhVupTOg8BjNUF335FONR1pOcQABSkeTKUJC2MhdiWGNkVyMoYdYoLAFwP1Q4r9Ti19a-CwYqF_OzgJr--0vghs4yn_U9xTDwaq_SO4-_BGd3RYXlQcOsDbUQp-fYat58F7k3YpgF6xNxTpDrkVwAHZr1lQxzzqccXvDcJ7syxGi5ZqQOV1WNEsWwYSQKwgUdFOrRU5ZDEurS29h3pdk0e9bddk7fqxpaR-G8qfdnwCkzCBoCk0qLo_KkOWmZHv-UMcBPhRRmkSGtrl2vCbGVqmumKM9xCIVQI_U0Zu2lk5o5G4nqoe6ypfkIimafJzQs5a3iSeUfgywg6ETC3qNrsQsw_hU-38K9_KC5t7Wmd_1KM6YjHlluMnib_pFkfRkipprWBAh3PhNSf4-z0-6PWSSuvFRcjn_89KUchpzB1DrFI2_yFo2IqyK8hFuTqNALnmSGSaJqNh7I4O4JDoYdbo7t4nrkbdpY7U-ClprNDvWjk5Y6xEeu6VtZVIcTcxaWr0KyItYL4-XVBUepAJm0hAuRSIg2BpS_7GDTKN76UqY3amApWkWo4woK8PRBg_ocotCpXdeCIYLzieJO7fDTifY-03gJvy2Pk0lXLM1U96iSFZb2XYB7CV81I9UikO6J9l3Z5olR9xjmtPgikMHhmI_d0IMuRqxlWcNxW405o4ciq7LGJWS-SAyNCZ4i5jYRUsfNGzrMiMsPZ2GgYoImCfs7CZPivVHVyLY8uuF_sBkaWY5LEGxR8FCRBkDdL_oPqh4MiXQO4rWFXOMNTUx2_-SW6hHSuhD5zss5qbcCMn5hwoACrr4rUHqEPDAALEDVQBUoX9ol-HXrn-7I8AxObB8S_ukfKE;
GCP_IAP_UID=111153160688352010463; _ym_uid=1708086836963991414;
_ym_d=1708086836; _ga=GA1.1.1079810620.1708086836; lang=ru-RU;
hubspotutk=dacf2bc1d7286f02d20fbe317118854d; __hssrc=1;
__stripe_mid=7b4b4d10-f2ec-4319-90bd-b6fdf0a9420f9821f5;
clientToken=eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IlJVUkZPVEUxUlRsQ09FSTROa0ZCUkVWQ1F6QTFNelF6T1RGQlJVUXhSREF6UVRBeVJVTTVRdyJ9.eyJuaWNrbmFtZSI6InZpa3Rvci52ZXRjaGlua2luKzEiLCJuYW1lIjoidmlrdG9yLnZldGNoaW5raW4rMUB1bWJyZWxsYWl0LmNvbSIsInBpY3R1cmUiOiJodHRwczovL3MuZ3JhdmF0YXIuY29tL2F2YXRhci84NjE5MjkzZDFjYjQyOGVmMDliYzkxMmRjOWJjNjdiZD9zPTQ4MCZyPXBnJmQ9aHR0cHMlM0ElMkYlMkZjZG4uYXV0aDAuY29tJTJGYXZhdGFycyUyRnZpLnBuZyIsInVwZGF0ZWRfYXQiOiIyMDI0LTAyLTE2VDEzOjA1OjQ1Ljc4NVoiLCJlbWFpbCI6InZpa3Rvci52ZXRjaGlua2luKzFAdW1icmVsbGFpdC5jb20iLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiaXNzIjoiaHR0cHM6Ly9vbmVza3lhcHAtc3RhZy5hdXRoMC5jb20vIiwiYXVkIjoib3pZMmtXYnhjakJHNVZ3SE1ZZzVQcndzRjhxT1hGWUIiLCJpYXQiOjE3MDgwODg3NDYsImV4cCI6MTcwOTgxNjc0Niwic3ViIjoiYXV0aDB8NjVjZGRjNjQ0NDI2ZmMzMDVkYmM3ZDFjIn0.rYTDiJfAgdgSTG85EtXM9rVejxkKYT3nEoRmHeJD6CxiEHA9R9-HMUpaxW5xMuR-aN3ZpGmCcrysc6Inpumfoq24KHNYDPkad5mzBjxYx1Sj2YuO8gBGfR8f3TACSSXTTz36BUOrFMu1b4jZdbD24LECnSrprPz6EI1n-jYF5k2jCmdEyNbS0VdcL3lGd7XxdZoSRZXCcU561a25aGHVG18t0llz4Wvo8L_s53H77lK7V3Vu1McX_8UF-Skg4CIzYXNY7QgV8qvWN76p9_g3kuXiyZynUfUz_mfGA1RkiU2yZtYJRXwPmQWuNgxyLc5venO4LbyrOd-P3ox8NDcJLA;
_ym_isad=1;
__hstc=125115733.dacf2bc1d7286f02d20fbe317118854d.1708086838752.1708271460282.1708273327661.3;
__stripe_sid=2d7affc6-7505-423d-aebf-5cea07682e24d1d342;
__hssc=125115733.3.1708273327661;
_ga_7QX004RKW2=GS1.1.1708273324.4.1.1708276012.0.0.0
Content-Type: application/json
json:
    variables: null
query: |
query GetAllLanguages {
  locale {
    standard {
      languages {
        id
        name
      }
      regions {
        id
        name
      }
    }
  }
}
- post:
url: /api/graphql
headers:
    Cookie: __Host-GCP_IAP_AUTH_TOKEN_24134F357731336F=ASIj7MiMmMisplKfJ3cdYk7eiHlKCgdHuqYlTrsUBiVKHf-XUOn2OmkgamTbxkaIgaZf_epK7X3EZTYh9i1NetXotbNP31hW6uHb_aBS1bgSe1iyPbSoJcvlun3aaNxtxmj901Nv32FSm6A_8aqatnyTZdqEMBY7H6psZF25Ktn4K_jTJhxRjqnvC1e-Xn9ETPO_Sl9bcE3I9m_t5mJ0R7nt_kjnhUirm1FIBnpKNKWPNw21S4rbC_ZcraGqRog_J0dvOO8ckto262sBePjYO_d3JUSN3i6-TAKoAooDiblSVAGmjdeVIZ2_gPOyYAh6jZZkdK014JQo7RburRkzG6YIFSlEKqXbOSyuPsYjQIvXDZcaQJPGT4HsKDmqgQcfNaqY8gUJGUI8mSGzlVlw8dV8kdTBJwl9Q-C3krq-k5NEqXYF0G5ndrKdyFRkjvTp31wuZDRbZYot4SBaKppQepiV9H2JheVKpf_6a6kJOFJxBinIUWTF2vigN61RBKxCgDOCI9FGHMtttfZwWXIbHU9mIb3bildZCObgwmmDIOVc1t51SLo6CVB8PoxDTt0Vc4_1H8WWb7UkC4Acr6x1C4Q8BvKHElnJieC1_ziNFqV-avzNCOe54cDwVt1SCD9G7w_S06friUenIaPVrVz3qWicNH8fFiWM4_tgcCy0gClot9-s78CAb6yKslM7YSC4kJIiPriIgOqIiqstdlYI8UZ72fmajQCaZuyuE797AQmtkAc3GeQ5-NLLSmo7tU6MKiF-fUFTADthJtGqae1OrVeG43cAE2UyWowvEmrrragTAC7csoEkPnvFZ-aGwXD2Nm55Ehxr4KFWXz-MgUzdkcEucknjPm7prG9U1hmyuOVSCIJM3Bf_xIOvZ2xUASiEEUsPE5wEuQUXvy2UNuHu2ERh7lOfskcLBhovZY9FpIS7O1iqI07Gxer2ERT5sKHhysltrOiA4iamHYVmBacEaCKKI4OJCzsEIM4TJCzqII_ysk11hOb2GFOUnhVupTOg8BjNUF335FONR1pOcQABSkeTKUJC2MhdiWGNkVyMoYdYoLAFwP1Q4r9Ti19a-CwYqF_OzgJr--0vghs4yn_U9xTDwaq_SO4-_BGd3RYXlQcOsDbUQp-fYat58F7k3YpgF6xNxTpDrkVwAHZr1lQxzzqccXvDcJ7syxGi5ZqQOV1WNEsWwYSQKwgUdFOrRU5ZDEurS29h3pdk0e9bddk7fqxpaR-G8qfdnwCkzCBoCk0qLo_KkOWmZHv-UMcBPhRRmkSGtrl2vCbGVqmumKM9xCIVQI_U0Zu2lk5o5G4nqoe6ypfkIimafJzQs5a3iSeUfgywg6ETC3qNrsQsw_hU-38K9_KC5t7Wmd_1KM6YjHlluMnib_pFkfRkipprWBAh3PhNSf4-z0-6PWSSuvFRcjn_89KUchpzB1DrFI2_yFo2IqyK8hFuTqNALnmSGSaJqNh7I4O4JDoYdbo7t4nrkbdpY7U-ClprNDvWjk5Y6xEeu6VtZVIcTcxaWr0KyItYL4-XVBUepAJm0hAuRSIg2BpS_7GDTKN76UqY3amApWkWo4woK8PRBg_ocotCpXdeCIYLzieJO7fDTifY-03gJvy2Pk0lXLM1U96iSFZb2XYB7CV81I9UikO6J9l3Z5olR9xjmtPgikMHhmI_d0IMuRqxlWcNxW405o4ciq7LGJWS-SAyNCZ4i5jYRUsfNGzrMiMsPZ2GgYoImCfs7CZPivVHVyLY8uuF_sBkaWY5LEGxR8FCRBkDdL_oPqh4MiXQO4rWFXOMNTUx2_-SW6hHSuhD5zss5qbcCMn5hwoACrr4rUHqEPDAALEDVQBUoX9ol-HXrn-7I8AxObB8S_ukfKE;
GCP_IAP_UID=111153160688352010463; _ym_uid=1708086836963991414;
_ym_d=1708086836; _ga=GA1.1.1079810620.1708086836; lang=ru-RU;
hubspotutk=dacf2bc1d7286f02d20fbe317118854d; __hssrc=1;
__stripe_mid=7b4b4d10-f2ec-4319-90bd-b6fdf0a9420f9821f5;
clientToken=eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IlJVUkZPVEUxUlRsQ09FSTROa0ZCUkVWQ1F6QTFNelF6T1RGQlJVUXhSREF6UVRBeVJVTTVRdyJ9.eyJuaWNrbmFtZSI6InZpa3Rvci52ZXRjaGlua2luKzEiLCJuYW1lIjoidmlrdG9yLnZldGNoaW5raW4rMUB1bWJyZWxsYWl0LmNvbSIsInBpY3R1cmUiOiJodHRwczovL3MuZ3JhdmF0YXIuY29tL2F2YXRhci84NjE5MjkzZDFjYjQyOGVmMDliYzkxMmRjOWJjNjdiZD9zPTQ4MCZyPXBnJmQ9aHR0cHMlM0ElMkYlMkZjZG4uYXV0aDAuY29tJTJGYXZhdGFycyUyRnZpLnBuZyIsInVwZGF0ZWRfYXQiOiIyMDI0LTAyLTE2VDEzOjA1OjQ1Ljc4NVoiLCJlbWFpbCI6InZpa3Rvci52ZXRjaGlua2luKzFAdW1icmVsbGFpdC5jb20iLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiaXNzIjoiaHR0cHM6Ly9vbmVza3lhcHAtc3RhZy5hdXRoMC5jb20vIiwiYXVkIjoib3pZMmtXYnhjakJHNVZ3SE1ZZzVQcndzRjhxT1hGWUIiLCJpYXQiOjE3MDgwODg3NDYsImV4cCI6MTcwOTgxNjc0Niwic3ViIjoiYXV0aDB8NjVjZGRjNjQ0NDI2ZmMzMDVkYmM3ZDFjIn0.rYTDiJfAgdgSTG85EtXM9rVejxkKYT3nEoRmHeJD6CxiEHA9R9-HMUpaxW5xMuR-aN3ZpGmCcrysc6Inpumfoq24KHNYDPkad5mzBjxYx1Sj2YuO8gBGfR8f3TACSSXTTz36BUOrFMu1b4jZdbD24LECnSrprPz6EI1n-jYF5k2jCmdEyNbS0VdcL3lGd7XxdZoSRZXCcU561a25aGHVG18t0llz4Wvo8L_s53H77lK7V3Vu1McX_8UF-Skg4CIzYXNY7QgV8qvWN76p9_g3kuXiyZynUfUz_mfGA1RkiU2yZtYJRXwPmQWuNgxyLc5venO4LbyrOd-P3ox8NDcJLA;
_ym_isad=1;
__hstc=125115733.dacf2bc1d7286f02d20fbe317118854d.1708086838752.1708271460282.1708273327661.3;
__stripe_sid=2d7affc6-7505-423d-aebf-5cea07682e24d1d342;
__hssc=125115733.3.1708273327661;
_ga_7QX004RKW2=GS1.1.1708273324.4.1.1708276012.0.0.0
Content-Type: application/json
json:
    variables:
        title: 2testetes23
description: ""
query: |
mutation CreateApp($title: String!, $description: String) {
  createApp(title: $title, description: $description) {
    id
    title
    description
    locale {
      regions {
        id
        name
      }
    }
  }
}
- post:
url: /api/graphql
headers:
    Cookie: __Host-GCP_IAP_AUTH_TOKEN_24134F357731336F=ASIj7MiMmMisplKfJ3cdYk7eiHlKCgdHuqYlTrsUBiVKHf-XUOn2OmkgamTbxkaIgaZf_epK7X3EZTYh9i1NetXotbNP31hW6uHb_aBS1bgSe1iyPbSoJcvlun3aaNxtxmj901Nv32FSm6A_8aqatnyTZdqEMBY7H6psZF25Ktn4K_jTJhxRjqnvC1e-Xn9ETPO_Sl9bcE3I9m_t5mJ0R7nt_kjnhUirm1FIBnpKNKWPNw21S4rbC_ZcraGqRog_J0dvOO8ckto262sBePjYO_d3JUSN3i6-TAKoAooDiblSVAGmjdeVIZ2_gPOyYAh6jZZkdK014JQo7RburRkzG6YIFSlEKqXbOSyuPsYjQIvXDZcaQJPGT4HsKDmqgQcfNaqY8gUJGUI8mSGzlVlw8dV8kdTBJwl9Q-C3krq-k5NEqXYF0G5ndrKdyFRkjvTp31wuZDRbZYot4SBaKppQepiV9H2JheVKpf_6a6kJOFJxBinIUWTF2vigN61RBKxCgDOCI9FGHMtttfZwWXIbHU9mIb3bildZCObgwmmDIOVc1t51SLo6CVB8PoxDTt0Vc4_1H8WWb7UkC4Acr6x1C4Q8BvKHElnJieC1_ziNFqV-avzNCOe54cDwVt1SCD9G7w_S06friUenIaPVrVz3qWicNH8fFiWM4_tgcCy0gClot9-s78CAb6yKslM7YSC4kJIiPriIgOqIiqstdlYI8UZ72fmajQCaZuyuE797AQmtkAc3GeQ5-NLLSmo7tU6MKiF-fUFTADthJtGqae1OrVeG43cAE2UyWowvEmrrragTAC7csoEkPnvFZ-aGwXD2Nm55Ehxr4KFWXz-MgUzdkcEucknjPm7prG9U1hmyuOVSCIJM3Bf_xIOvZ2xUASiEEUsPE5wEuQUXvy2UNuHu2ERh7lOfskcLBhovZY9FpIS7O1iqI07Gxer2ERT5sKHhysltrOiA4iamHYVmBacEaCKKI4OJCzsEIM4TJCzqII_ysk11hOb2GFOUnhVupTOg8BjNUF335FONR1pOcQABSkeTKUJC2MhdiWGNkVyMoYdYoLAFwP1Q4r9Ti19a-CwYqF_OzgJr--0vghs4yn_U9xTDwaq_SO4-_BGd3RYXlQcOsDbUQp-fYat58F7k3YpgF6xNxTpDrkVwAHZr1lQxzzqccXvDcJ7syxGi5ZqQOV1WNEsWwYSQKwgUdFOrRU5ZDEurS29h3pdk0e9bddk7fqxpaR-G8qfdnwCkzCBoCk0qLo_KkOWmZHv-UMcBPhRRmkSGtrl2vCbGVqmumKM9xCIVQI_U0Zu2lk5o5G4nqoe6ypfkIimafJzQs5a3iSeUfgywg6ETC3qNrsQsw_hU-38K9_KC5t7Wmd_1KM6YjHlluMnib_pFkfRkipprWBAh3PhNSf4-z0-6PWSSuvFRcjn_89KUchpzB1DrFI2_yFo2IqyK8hFuTqNALnmSGSaJqNh7I4O4JDoYdbo7t4nrkbdpY7U-ClprNDvWjk5Y6xEeu6VtZVIcTcxaWr0KyItYL4-XVBUepAJm0hAuRSIg2BpS_7GDTKN76UqY3amApWkWo4woK8PRBg_ocotCpXdeCIYLzieJO7fDTifY-03gJvy2Pk0lXLM1U96iSFZb2XYB7CV81I9UikO6J9l3Z5olR9xjmtPgikMHhmI_d0IMuRqxlWcNxW405o4ciq7LGJWS-SAyNCZ4i5jYRUsfNGzrMiMsPZ2GgYoImCfs7CZPivVHVyLY8uuF_sBkaWY5LEGxR8FCRBkDdL_oPqh4MiXQO4rWFXOMNTUx2_-SW6hHSuhD5zss5qbcCMn5hwoACrr4rUHqEPDAALEDVQBUoX9ol-HXrn-7I8AxObB8S_ukfKE;
GCP_IAP_UID=111153160688352010463; _ym_uid=1708086836963991414;
_ym_d=1708086836; _ga=GA1.1.1079810620.1708086836; lang=ru-RU;
hubspotutk=dacf2bc1d7286f02d20fbe317118854d; __hssrc=1;
__stripe_mid=7b4b4d10-f2ec-4319-90bd-b6fdf0a9420f9821f5;
clientToken=eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IlJVUkZPVEUxUlRsQ09FSTROa0ZCUkVWQ1F6QTFNelF6T1RGQlJVUXhSREF6UVRBeVJVTTVRdyJ9.eyJuaWNrbmFtZSI6InZpa3Rvci52ZXRjaGlua2luKzEiLCJuYW1lIjoidmlrdG9yLnZldGNoaW5raW4rMUB1bWJyZWxsYWl0LmNvbSIsInBpY3R1cmUiOiJodHRwczovL3MuZ3JhdmF0YXIuY29tL2F2YXRhci84NjE5MjkzZDFjYjQyOGVmMDliYzkxMmRjOWJjNjdiZD9zPTQ4MCZyPXBnJmQ9aHR0cHMlM0ElMkYlMkZjZG4uYXV0aDAuY29tJTJGYXZhdGFycyUyRnZpLnBuZyIsInVwZGF0ZWRfYXQiOiIyMDI0LTAyLTE2VDEzOjA1OjQ1Ljc4NVoiLCJlbWFpbCI6InZpa3Rvci52ZXRjaGlua2luKzFAdW1icmVsbGFpdC5jb20iLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiaXNzIjoiaHR0cHM6Ly9vbmVza3lhcHAtc3RhZy5hdXRoMC5jb20vIiwiYXVkIjoib3pZMmtXYnhjakJHNVZ3SE1ZZzVQcndzRjhxT1hGWUIiLCJpYXQiOjE3MDgwODg3NDYsImV4cCI6MTcwOTgxNjc0Niwic3ViIjoiYXV0aDB8NjVjZGRjNjQ0NDI2ZmMzMDVkYmM3ZDFjIn0.rYTDiJfAgdgSTG85EtXM9rVejxkKYT3nEoRmHeJD6CxiEHA9R9-HMUpaxW5xMuR-aN3ZpGmCcrysc6Inpumfoq24KHNYDPkad5mzBjxYx1Sj2YuO8gBGfR8f3TACSSXTTz36BUOrFMu1b4jZdbD24LECnSrprPz6EI1n-jYF5k2jCmdEyNbS0VdcL3lGd7XxdZoSRZXCcU561a25aGHVG18t0llz4Wvo8L_s53H77lK7V3Vu1McX_8UF-Skg4CIzYXNY7QgV8qvWN76p9_g3kuXiyZynUfUz_mfGA1RkiU2yZtYJRXwPmQWuNgxyLc5venO4LbyrOd-P3ox8NDcJLA;
_ym_isad=1;
__hstc=125115733.dacf2bc1d7286f02d20fbe317118854d.1708086838752.1708271460282.1708273327661.3;
__stripe_sid=2d7affc6-7505-423d-aebf-5cea07682e24d1d342;
__hssc=125115733.3.1708273327661;
_ga_7QX004RKW2=GS1.1.1708273324.4.1.1708276012.0.0.0
Content-Type: application/json
json:
    variables:
        appId:
            sourceLanguageId: en
effectType: display-language
unmodifiedLocales: []
previousSourceLang: ""
query: |
mutation UpdateAppSourceLanguage(
    $appId: ID!
    $sourceLanguageId: String!
    $effectType: String!
    $unmodifiedLocales: [String]
$previousSourceLang: String
) {
  updateSourceLanguage(
      appId: $appId
  sourceLanguageId: $sourceLanguageId
  unmodifiedLocales: $unmodifiedLocales
  previousSourceLang: $previousSourceLang
) {
    id
    title
    locale {
      regions {
        id
        name
        languages {
          id
          name
          populationPerCent
          enabledPlatformIds
        }
      }
    }
    product {
      conductor {
        effects(type: $effectType) {
          id
          title
          isEnabled
          step
          experience {
            type
            input {
              languages {
                id
                isDefault
                isPublished
              }
              regions {
                id
                isDefault
                isPublished
              }
              theme
              htmlTag
              respectOrder
              isEnabledLocalizedContentWithoutI18N
            }
            output {
              webTransition {
                transitionType
                mappings {
                  localeId
                  location
                  domain
                }
                isReloadPage
              }
              webhooks {
                id
                endpoint
              }
            }
          }
        }
      }
    }
  }
}
- post:
url: /api/graphql
headers:
    Cookie: __Host-GCP_IAP_AUTH_TOKEN_24134F357731336F=ASIj7MjuV49iXY7pCEWe1zfPj9mWb9kiIPT5j3MNMlKKMXTEZKDUbcji9qZbZnJMmnFUW3fRWdZoXOM56tYToajoulWQ6pcwtSB5S9W6qXnFUvixuYu7sMU4icVa67Vv6-sKAdQFbMm0Twl79LzGYVQ-5jEKHhHhEeGK2x2xaANH9pepfYC_Bbo3SUdgMPyds4IULiu-c7RrAkgn7c6Fh6IVhcnij2J9Tn-rMAJNeuwuvXxOkbJs2wJFHZ6Tt7KeeknprcUp85eYUfPsjh32w3uK_I3cIOtfPp1hrlbTYC6EXH6g1GTC-hpuIqR_a8N3hGHY5pQgtQ3KwN5xdrsb6PGg5SXhGoX3hKTqKSK1fUPWjpRSkldkUpfMR2vv-8lD2sMc5oJBgbIk5dIRgbzuhwxi3KRFLdxtiXRRUQWN_FANJQSkLzPlO0CD2m3vAzyAw1a_Uh4C_HBxnXmNU-nsa_yXTV1xBFRhP7LHhPJrFomYC4CbR_b8nFnWsIRP_c_HSumQBiFZ1Zi1bkzX4YskqnPDsQ0CresULdgoFuPkBPdxgkYsTezQP-mCx3_bWmJSjuVVoIwU5I9bycl2S8TJEM8nPAvBfUyynzmA5lLCjdb0C2U43J0b7hX4PZPWNKk1ydBTr4rOH-GT0rQeinpXcxkQsTHWROUQ7_t4a3K6rp_eB2wy9p_cVVpVpJIrLf09_Jurr0VZnAM5FuNFEZf5JE2DYnMwJPo6H_fRLHT8vX7NiCUFy5atghYW1iddrDqGFsCuUDhGQpUSK95rh1TUP9GD48ZuWUrWFDFBHYGFNVeAiQ_5j7YPwbTNgPiSuYOJMl-0DOSuUKdirM28NKsV16uIsE_6_sK2_TEgaOJIN1fBan3qSCR9-xet6r6Nl8UXbQEha_nOC0ZyX5qNTbriV7wZtRaWNiJiENXKf-tIqavK7p_a-WktIM5k-fISQ-rGJDZ2g7A6nwIyc1XUrjClDsxAUTWbbaXvz5IFFoqzfFrLtStwX6VripiasbtUmmY_gVFU76PuN2tMsqg-OPUDrDTKKLW2CfHbEGJBvp0czcmuMcGnL-BVd9P5Qt2RfLLE2Dnl5-0n4EaolBAhrhKKqFdYE-4Cyz2jSQ4Fx9QMfF1TJD1a_ywhRuKSMbI3QFo0b-XfWLGUmKROgnI6x26mkfrguA7uxcR33Vwu8BjgL8wgB6ppkNyiquzK-pnfFCSCH4qT5h6i4QksnZ8jKTcctCM6R_tHsCkhGO_DVaciU-LpwNTTH-MhMFpNwPWvYf1zYRaYkkBJQmjCckTstETOBIxEfJa5jDbwOMUMhlYvUUgm7td8Qjq2V9CmZxohuGCgFy2yOLjaF_HyIfomW-4y3YvlLDwjCEhfjlmUjLRYojJRR1AMqAgCUPBDWSel2GEdDKj-ZHOnTFqfGrmBGCa9G7RLr70zf2G0j_6mQglP2kLo8jzFsbOVnepub_ILqYeFfQaB1kE2hgcrk4PayYxTi6VZrYcHJ0BXDXARDr2quRmlIfQlpMc5wm8y9gGBu8vRpDNZmaX6DB-cVMuxlgEF-j7enCjqX7skFwpHs59nK2cOtWfpqCiniYxoA6H8CvD6_5RLGVgTqblpeD98rtP9tz7mLiH_gg8kV265_2gbcFzaJ6IPjPARYJFYjlzawkUIYWABTxszKpiiAZNewu-sziAkq0wuwxTfnJGe6CuDgcSp8hD9LP0R9BjRJ-VeKSIrmzhroM1LLBG8SI_Dl1oX5pb9XkPLqYWZ-MgAF6Z2WMYc9gdjFDRt69gyPCwS2tTVbof7A8CvAl6iTlOnjHw6RKe9_HAkR3asagoD2FfTf-fGskaQBaRKjYOUJacM3907WSC4Ex17lUzD3BNydTltBHQ;
GCP_IAP_UID=111153160688352010463;
_ga=GA1.1.1548547009.1707911928; _ym_uid=1707911928143275293;
_ym_d=1707911928; lang=ru-RU;
hubspotutk=3c2e609f9fbd56debd54e5f71e270e94;
__hssrc=1;             __stripe_mid=b96ce807-6884-4537-8556-fad3fb384ffd9f75d1;
_ym_isad=1;
clientToken=eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IlJVUkZPVEUxUlRsQ09FSTROa0ZCUkVWQ1F6QTFNelF6T1RGQlJVUXhSREF6UVRBeVJVTTVRdyJ9.eyJuaWNrbmFtZSI6InZpa3Rvci52ZXRjaGlua2luKzEiLCJuYW1lIjoidmlrdG9yLnZldGNoaW5raW4rMUB1bWJyZWxsYWl0LmNvbSIsInBpY3R1cmUiOiJodHRwczovL3MuZ3JhdmF0YXIuY29tL2F2YXRhci84NjE5MjkzZDFjYjQyOGVmMDliYzkxMmRjOWJjNjdiZD9zPTQ4MCZyPXBnJmQ9aHR0cHMlM0ElMkYlMkZjZG4uYXV0aDAuY29tJTJGYXZhdGFycyUyRnZpLnBuZyIsInVwZGF0ZWRfYXQiOiIyMDI0LTAyLTE1VDEyOjQ2OjUxLjAwNVoiLCJlbWFpbCI6InZpa3Rvci52ZXRjaGlua2luKzFAdW1icmVsbGFpdC5jb20iLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiaXNzIjoiaHR0cHM6Ly9vbmVza3lhcHAtc3RhZy5hdXRoMC5jb20vIiwiYXVkIjoib3pZMmtXYnhjakJHNVZ3SE1ZZzVQcndzRjhxT1hGWUIiLCJpYXQiOjE3MDgwMDEyMTEsImV4cCI6MTcwOTcyOTIxMSwic3ViIjoiYXV0aDB8NjVjZGRjNjQ0NDI2ZmMzMDVkYmM3ZDFjIn0.zXgjrwRJq3s-8eB-ukJPCiM9rLP7RYsWQw5wL52hxqKSgq0F7_b9UG1Zr1UjRTp0TpaK433uJkum7xGyrYJbRukCCAdbaSW3Q0675V_trEDxUSWApltJUPzFx8cjB70tInbwEntq_L9lgFPllmWIt_ufb00xM6gQ6Qn9Q95RAS10lqkCRz1f0tggBpfmE8ePE0vNQRaLxd_xsjzPjIQg7vJk9BD2rADLeXbe85zmGmredfTazlS9bciRWD9IGpsXKAwTlOiCh3LTuk8ylS06pLYyWI5Tj4BylOYSF6cQ7YZHhwU4an6b5SsTDEIFMKmT_7G5HZEeDUNeGnXACi6U8A;
__hstc=125115733.3c2e609f9fbd56debd54e5f71e270e94.1707911931333.1708001397876.1708004207708.8;
__hssc=125115733.1.1708004207708;
__stripe_sid=b60017c6-477e-4aad-93af-3b46b5186829aaa814;
_ga_7QX004RKW2=GS1.1.1708004199.8.1.1708005884.0.0.0
Content-Type: application/json
json:
    variables:
        appId:
            effectType: display-language
query: |
query GetAppEffect($appId: ID!, $effectType: String!) {
  app(id: $appId) {
    id
    title
    platforms {
      platformId
      isInstalled
      installationType
      apiKey
    }
    locale {
      regions {
        id
        name
        languages {
          id
          name
          populationPerCent
          enabledPlatformIds
        }
      }
    }
    product {
      conductor {
        effects(type: $effectType) {
          id
          title
          isEnabled
          step
          experience {
            type
            input {
              languages {
                id
                name
                isDefault
                isPublished
              }
              regions {
                id
                name
                isDefault
                isPublished
              }
              theme
              htmlTag
              webDomain
              respectOrder
              isEnabledLocalizedContentWithoutI18N
            }
            output {
              webTransition {
                transitionType
                mappings {
                  localeId
                  location
                  domain
                }
                isReloadPage
              }
              webhooks {
                id
                endpoint
              }
            }
          }
        }
      }
    }
  }
}
- post:
url: /api/graphql
headers:
    Cookie: __Host-GCP_IAP_AUTH_TOKEN_24134F357731336F=ASIj7MiMmMisplKfJ3cdYk7eiHlKCgdHuqYlTrsUBiVKHf-XUOn2OmkgamTbxkaIgaZf_epK7X3EZTYh9i1NetXotbNP31hW6uHb_aBS1bgSe1iyPbSoJcvlun3aaNxtxmj901Nv32FSm6A_8aqatnyTZdqEMBY7H6psZF25Ktn4K_jTJhxRjqnvC1e-Xn9ETPO_Sl9bcE3I9m_t5mJ0R7nt_kjnhUirm1FIBnpKNKWPNw21S4rbC_ZcraGqRog_J0dvOO8ckto262sBePjYO_d3JUSN3i6-TAKoAooDiblSVAGmjdeVIZ2_gPOyYAh6jZZkdK014JQo7RburRkzG6YIFSlEKqXbOSyuPsYjQIvXDZcaQJPGT4HsKDmqgQcfNaqY8gUJGUI8mSGzlVlw8dV8kdTBJwl9Q-C3krq-k5NEqXYF0G5ndrKdyFRkjvTp31wuZDRbZYot4SBaKppQepiV9H2JheVKpf_6a6kJOFJxBinIUWTF2vigN61RBKxCgDOCI9FGHMtttfZwWXIbHU9mIb3bildZCObgwmmDIOVc1t51SLo6CVB8PoxDTt0Vc4_1H8WWb7UkC4Acr6x1C4Q8BvKHElnJieC1_ziNFqV-avzNCOe54cDwVt1SCD9G7w_S06friUenIaPVrVz3qWicNH8fFiWM4_tgcCy0gClot9-s78CAb6yKslM7YSC4kJIiPriIgOqIiqstdlYI8UZ72fmajQCaZuyuE797AQmtkAc3GeQ5-NLLSmo7tU6MKiF-fUFTADthJtGqae1OrVeG43cAE2UyWowvEmrrragTAC7csoEkPnvFZ-aGwXD2Nm55Ehxr4KFWXz-MgUzdkcEucknjPm7prG9U1hmyuOVSCIJM3Bf_xIOvZ2xUASiEEUsPE5wEuQUXvy2UNuHu2ERh7lOfskcLBhovZY9FpIS7O1iqI07Gxer2ERT5sKHhysltrOiA4iamHYVmBacEaCKKI4OJCzsEIM4TJCzqII_ysk11hOb2GFOUnhVupTOg8BjNUF335FONR1pOcQABSkeTKUJC2MhdiWGNkVyMoYdYoLAFwP1Q4r9Ti19a-CwYqF_OzgJr--0vghs4yn_U9xTDwaq_SO4-_BGd3RYXlQcOsDbUQp-fYat58F7k3YpgF6xNxTpDrkVwAHZr1lQxzzqccXvDcJ7syxGi5ZqQOV1WNEsWwYSQKwgUdFOrRU5ZDEurS29h3pdk0e9bddk7fqxpaR-G8qfdnwCkzCBoCk0qLo_KkOWmZHv-UMcBPhRRmkSGtrl2vCbGVqmumKM9xCIVQI_U0Zu2lk5o5G4nqoe6ypfkIimafJzQs5a3iSeUfgywg6ETC3qNrsQsw_hU-38K9_KC5t7Wmd_1KM6YjHlluMnib_pFkfRkipprWBAh3PhNSf4-z0-6PWSSuvFRcjn_89KUchpzB1DrFI2_yFo2IqyK8hFuTqNALnmSGSaJqNh7I4O4JDoYdbo7t4nrkbdpY7U-ClprNDvWjk5Y6xEeu6VtZVIcTcxaWr0KyItYL4-XVBUepAJm0hAuRSIg2BpS_7GDTKN76UqY3amApWkWo4woK8PRBg_ocotCpXdeCIYLzieJO7fDTifY-03gJvy2Pk0lXLM1U96iSFZb2XYB7CV81I9UikO6J9l3Z5olR9xjmtPgikMHhmI_d0IMuRqxlWcNxW405o4ciq7LGJWS-SAyNCZ4i5jYRUsfNGzrMiMsPZ2GgYoImCfs7CZPivVHVyLY8uuF_sBkaWY5LEGxR8FCRBkDdL_oPqh4MiXQO4rWFXOMNTUx2_-SW6hHSuhD5zss5qbcCMn5hwoACrr4rUHqEPDAALEDVQBUoX9ol-HXrn-7I8AxObB8S_ukfKE;
GCP_IAP_UID=111153160688352010463; _ym_uid=1708086836963991414;
_ym_d=1708086836; _ga=GA1.1.1079810620.1708086836; lang=ru-RU;
hubspotutk=dacf2bc1d7286f02d20fbe317118854d; __hssrc=1;
__stripe_mid=7b4b4d10-f2ec-4319-90bd-b6fdf0a9420f9821f5;
clientToken=eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IlJVUkZPVEUxUlRsQ09FSTROa0ZCUkVWQ1F6QTFNelF6T1RGQlJVUXhSREF6UVRBeVJVTTVRdyJ9.eyJuaWNrbmFtZSI6InZpa3Rvci52ZXRjaGlua2luKzEiLCJuYW1lIjoidmlrdG9yLnZldGNoaW5raW4rMUB1bWJyZWxsYWl0LmNvbSIsInBpY3R1cmUiOiJodHRwczovL3MuZ3JhdmF0YXIuY29tL2F2YXRhci84NjE5MjkzZDFjYjQyOGVmMDliYzkxMmRjOWJjNjdiZD9zPTQ4MCZyPXBnJmQ9aHR0cHMlM0ElMkYlMkZjZG4uYXV0aDAuY29tJTJGYXZhdGFycyUyRnZpLnBuZyIsInVwZGF0ZWRfYXQiOiIyMDI0LTAyLTE2VDEzOjA1OjQ1Ljc4NVoiLCJlbWFpbCI6InZpa3Rvci52ZXRjaGlua2luKzFAdW1icmVsbGFpdC5jb20iLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiaXNzIjoiaHR0cHM6Ly9vbmVza3lhcHAtc3RhZy5hdXRoMC5jb20vIiwiYXVkIjoib3pZMmtXYnhjakJHNVZ3SE1ZZzVQcndzRjhxT1hGWUIiLCJpYXQiOjE3MDgwODg3NDYsImV4cCI6MTcwOTgxNjc0Niwic3ViIjoiYXV0aDB8NjVjZGRjNjQ0NDI2ZmMzMDVkYmM3ZDFjIn0.rYTDiJfAgdgSTG85EtXM9rVejxkKYT3nEoRmHeJD6CxiEHA9R9-HMUpaxW5xMuR-aN3ZpGmCcrysc6Inpumfoq24KHNYDPkad5mzBjxYx1Sj2YuO8gBGfR8f3TACSSXTTz36BUOrFMu1b4jZdbD24LECnSrprPz6EI1n-jYF5k2jCmdEyNbS0VdcL3lGd7XxdZoSRZXCcU561a25aGHVG18t0llz4Wvo8L_s53H77lK7V3Vu1McX_8UF-Skg4CIzYXNY7QgV8qvWN76p9_g3kuXiyZynUfUz_mfGA1RkiU2yZtYJRXwPmQWuNgxyLc5venO4LbyrOd-P3ox8NDcJLA;
_ym_isad=1;
__hstc=125115733.dacf2bc1d7286f02d20fbe317118854d.1708086838752.1708271460282.1708273327661.3;
__stripe_sid=2d7affc6-7505-423d-aebf-5cea07682e24d1d342;
__hssc=125115733.3.1708273327661;
_ga_7QX004RKW2=GS1.1.1708273324.4.1.1708276012.0.0.0
Content-Type: application/json
json:
    variables:
        appId:
            effectId:
                effectLocales:
                    - zh_Hans
                    - zh_Hant
                    - en
query: |
mutation UpdateEffectLocales(
    $appId: ID!
    $effectId: ID!
    $effectLocales: [String]
) {
  updateEffectLocales(
      appId: $appId
  effectId: $effectId
  effectLocales: $effectLocales
) {
    id
  }
}
